import pygame
import os
import random

class Settings():
    width = 900
    height = 700
    title = "Bubblegame.Wildenhues"                                                                
    file_path = os.path.dirname(os.path.abspath(__file__)) 
    images_path = os.path.join(file_path, "images")
    score = 0
    fps = 60 
    time = 60
    border = 10
    bubblecount = 0
    gameover = False
    try:
        f = open("highscore.txt", "r")
        highscore = int(f.readline())
        f.close()
    except:
        f = open("highscore.txt", "w")
        f.write(str(0))
        f.close()
        highscore = 0

    @staticmethod
    def get_dim():
        return (Settings.width, Settings.height)


class Cursor(pygame.sprite.Sprite):
    def __init__(self, pygame):
        super().__init__()
        self.image = pygame.image.load(os.path.join(Settings.images_path, "NormalCursor.PNG")).convert_alpha()
        self.image = pygame.transform.scale(self.image, (22, 32))
        self.rect = self.image.get_rect()
        self.collision = False

    def update(self):
        self.rect.top = pygame.mouse.get_pos()[1]
        self.rect.left = pygame.mouse.get_pos()[0]
        if self.collision == True: 
            self.image = pygame.image.load(os.path.join(Settings.images_path, "HoveringCursor.PNG")).convert_alpha()
            self.image = pygame.transform.scale(self.image, (46, 38))
        else:
            self.image = pygame.image.load(os.path.join(Settings.images_path, "NormalCursor.PNG")).convert_alpha()
            self.image = pygame.transform.scale(self.image, (22, 32))


class Cursor2(pygame.sprite.Sprite):
    def __init__(self, pygame):
        super().__init__()
        self.image = pygame.image.load(os.path.join(Settings.images_path, "NormalCursor.PNG")).convert_alpha()
        self.image = pygame.transform.scale(self.image, (1, 1))
        self.rect = self.image.get_rect()
        self.collision = False

    def update(self):
        self.rect.top = pygame.mouse.get_pos()[1]
        self.rect.left = pygame.mouse.get_pos()[0]

class Bubble(pygame.sprite.Sprite):
    def __init__(self, pygame, Cursor):
        super().__init__()
        self.image = pygame.image.load(os.path.join(Settings.images_path, "Bubble1.png")).convert_alpha()
        self.image = pygame.transform.scale(self.image, (10, 10))
        self.rect = self.image.get_rect()
        self.rect.top = random.randrange( 0 + Settings.border , Settings.height - self.rect.height - Settings.border)
        self.rect.left = random.randrange(0 + Settings.border , Settings.width - self.rect.width - Settings.border)
        Settings.bubblecount += 1
        self.growrate = random.randrange(1, 5)
        self.time = 0
        self.radius = 5
        self.Bubble = Cursor

    def update(self):
        self.time += 1
        if self.time >= Settings.time:
            self.radius += self.growrate 
            self.image = pygame.image.load(os.path.join(Settings.images_path, "Bubble1.png")).convert_alpha()
            self.image = pygame.transform.scale(self.image, (self.radius * 2, self.radius * 2))
            self.time = 0
            self.rect.height += self.growrate * 2
            self.rect.width += self.growrate * 2
        if pygame.mouse.get_pressed()[0] and self.rect.top <= pygame.mouse.get_pos()[1] and self.rect.bottom >= pygame.mouse.get_pos()[1] and self.rect.left  <= pygame.mouse.get_pos()[0] and self.rect.right  >= pygame.mouse.get_pos()[0]:
            
            self.kill()
            Settings.bubblecount -= 1
            Settings.score += self.radius

        if self.rect.left <= 0:
            self.kill()
            Settings.bubblecount -= 1
            Settings.score += self.radius
        if self.rect.right >= Settings.width:
            self.kill()
            Settings.bubblecount -= 1
            Settings.score += self.radius
        if self.rect.top <= 0:
            self.kill()
            Settings.bubblecount -= 1
            Settings.score += self.radius
        if self.rect.bottom >= Settings.height:
            self.kill()
            Settings.bubblecount -= 1
            Settings.score += self.radius

class Game(object):
    def __init__(self):
        self.screen = pygame.display.set_mode(Settings.get_dim())
        pygame.display.set_caption(Settings.title)
        self.all_Bubbles = pygame.sprite.Group()
        
        pygame.font.init()
        self.font = pygame.font.SysFont("Cooper Black", 20)

        self.all_Cursors = pygame.sprite.Group()
        self.Cursor = Cursor(pygame)
        self.all_Cursors.add(self.Cursor)
        self.Cursor2 = Cursor2(pygame)
        self.all_Cursors.add(self.Cursor2)

        self.time = 0
        pygame.mouse.set_visible(False)

        self.background = pygame.image.load(os.path.join(Settings.images_path, "Background.jpg")).convert()
        self.background = pygame.transform.scale(self.background, (Settings.width, Settings.height))
        self.background_rect = self.background.get_rect()
        
        self.clock = pygame.time.Clock()
        self.done = False

    def run(self):
        while not self.done:
            self.clock.tick(Settings.fps)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.done = True
            

            collision = pygame.sprite.spritecollide(self.Cursor2, self.all_Bubbles, False)
            if collision:
                self.Cursor.collision = True               
            else: 
                self.Cursor.collision = False


            self.screen.blit(self.background, self.background_rect)
            self.time += 1
            if self.time >= Settings.time and Settings.bubblecount <= Settings.width / 60:
                self.time = 0
                self.Bubble = Bubble(pygame, self.Cursor)
                self.all_Bubbles.add(self.Bubble)
                if Settings.time >  13:
                    Settings.time -= 1
                    
            self.all_Bubbles.update()
            self.all_Bubbles.draw(self.screen)
            self.all_Cursors.update()
            self.all_Cursors.draw(self.screen)

            self.scoretext = self.font.render("Score: " + str(Settings.score) , False , (0,0,0))

            
            self.screen.blit(self.scoretext, (5, 10))

            if Settings.highscore < Settings.score:
                    Settings.highscore = Settings.score
                    
            self.highscoretext = self.font.render("Highscore: " + str(Settings.highscore) , False , (0,0,0))
            self.screen.blit(self.highscoretext, (5, 30))

            for bubble in self.all_Bubbles:
                    for bubble2 in self.all_Bubbles:
                        if bubble != bubble2:
                            collision = pygame.sprite.collide_circle(bubble, bubble2)
                            if collision == True:
                                Settings.gameover = True
                                print("Gameover")
                                self.done = True
                                f = open("highscore.txt", "w")
                                f.write(str(Settings.highscore))
                                f.close()


            pygame.display.flip()

                                
                                
                

if __name__ == '__main__':                      
    pygame.init()
    game = Game()
    game.run()
    pygame.quit()